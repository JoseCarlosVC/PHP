<?php
    define('NOMBRE_SERVIDOR', 'localhost');
    define('NOMBRE_USUARIO', 'jose');
    define('PASSWORD', 'aa');
    define('NOMBRE_BD', 'dwes');

    /*
    define('SERVIDOR', 'http://localhost:8888/DWES');
    define('RUTA_REGISTRO', SERVIDOR . '/registro.php');
    define('RUTA_REGISTRO_CORRECTO', SERVIDOR . '/registroCorrecto.php');
    define('RUTA_EDICION_CORRECTA', SERVIDOR . '/edicionCorrecta.php');
    define('RUTA_LOGIN', SERVIDOR . '/login.php');
    define('RUTA_LOGOUT', SERVIDOR . '/logout.php');
    */